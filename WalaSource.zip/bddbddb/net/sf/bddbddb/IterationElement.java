// IterationElement.java, created Jun 29, 2004
// Copyright (C) 2004 Michael Carbin
// Licensed under the terms of the GNU LGPL; see COPYING for details.
package net.sf.bddbddb;

/**
 * IterationElement
 * 
 * @author mcarbin
 * @version $Id: IterationElement.java 333 2004-10-16 04:36:10Z joewhaley $
 */
public interface IterationElement {
}
